import java.util.ArrayList;
import java.util.LinkedList;

public class buildList {
	private int vertices;
	private ArrayList<LinkedList<theList>> l;
	
	public buildList(int a) {
		this.vertices = a;
		l = new ArrayList<LinkedList<theList>>(vertices);
		for(int b=0; b<vertices; b++) {
			l.add(new LinkedList<theList>());
		}
	}
	
	public ArrayList<LinkedList<theList>> getList() {
		return l;
	}
	
	public boolean addOn(int ind, theList m) {
		if(l.get(ind).add(m)) {
			return true;
		}
		return false;
	}
	
	
	

}
