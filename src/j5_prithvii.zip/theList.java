
public class theList {
	int index, weight;
	String path = "";
	
	public theList(int index, int weight) {
		this.index = index;
		this.weight = weight;
	}
	
	public int getIndex() {
		return index;
	}
	
	public int getWeight() {
		return weight;
	}
	
	public String toString() {
		return String.valueOf(index)+": "+String.valueOf(weight);
	}
	
	public void setWeight(int weight) {
		this.weight = weight;
	} 
	
	
	public String getPath()
	{
		return path;
	}
	
	public void setPath(String s) {
		this.path = s;
	}
	

}
